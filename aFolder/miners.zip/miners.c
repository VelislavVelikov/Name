//--------------------------------------------
// NAME: Velislav Velikov
// CLASS: XI b
// NUMBER: 06
// PROBLEM: #2
//---------------------------------------------







#include<stdio.h>
#include<pthread.h>
#include<unistd.h>

int Gold = 0;
pthread_mutex_t mutex;
void *Miner(){

	int i;
	
	for(i = 0;i<20;i++){
		pthread_mutex_lock(&mutex);
		printf("Miner 1 gathered 10 gold\n");
		Gold += 10;
		pthread_mutex_unlock(&mutex);
		sleep(1);	
	}

}

void *Seller(){

	int i;

	for(i=0;i<20;i++){
		pthread_mutex_lock(&mutex);
		if(Gold < 10){
			printf("The warehouse is empty, cannot sell!\n");
			i--;
		}else {
			printf("Trader 1 sold 10 gold\n");
			Gold -= 10;
		}
		pthread_mutex_unlock(&mutex);
		sleep(1);
	}
}

int main(){
	pthread_t threads[2];
	
	pthread_mutex_init(&mutex, NULL);

	pthread_create(&threads[0], NULL, Miner, NULL);
	pthread_create(&threads[1], NULL, Seller, NULL);
	
	
 	pthread_join(threads[0],NULL);
	pthread_join(threads[1],NULL);
	
	pthread_mutex_destroy(&mutex);
	printf("Gold: %d\n",Gold);
	return 0;

}


/*



#include<stdio.h>
#include<unistd.h>
#include<pthread.h>

int Currency=0;
pthread_mutex_t mutex;

void *Gathering(){
int i;
for(i = 1;i<21;i++){
		pthread_mutex_lock(&mutex);
		printf("Miner 1 gathered 10 gold\n");
		Currency = Currency + 10;
		pthread_mutex_unlock(&mutex);
		sleep(2);	
	}
}

void *Selling(){
	int c;

	for(c=1;c<21;c++){
		pthread_mutex_lock(&mutex);
		if(Currency < 10){
			printf("The warehouse is empty, cannot sell!\n");
			c--;
		}else {
			printf("Trader 1 sold 10 gold\n");
			Currency = Currency - 10;
		}
		pthread_mutex_unlock(&mutex);
		sleep(2);
	}
}

int main (int argc, char *argv[])
{
	pthread_t threads[2];
	
	pthread_mutex_init(&mutex, NULL);

	pthread_create(&threads[0], NULL, Gathering, NULL);
	pthread_create(&threads[1], NULL, Selling, NULL);
	
	
 	pthread_join(threads[0],NULL);
	pthread_join(threads[1],NULL);
	
	pthread_mutex_destroy(&mutex);
	printf("Gold: %d\n",Currency);
	return 0;

}

//gcc -Wall -o miners -miners.c -pthread
