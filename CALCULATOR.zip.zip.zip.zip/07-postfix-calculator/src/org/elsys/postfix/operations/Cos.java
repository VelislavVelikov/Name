package org.elsys.postfix.operations;

import org.elsys.postfix.Calculator;

public class Cos extends AbstractOperation implements Operation {

	public Cos(Calculator calculator) {
		super(calculator, "cos");
		
	}

	@Override
	public void calculate() {
		Double value = getCalculator().popValue();
		getCalculator().addValue(value);
		Double cos = Math.cos(value);
		getCalculator().addValue(cos);

	}

}
